function [lp] = logProd(x)
lp = sum(x);
end
