clear all
load('multigauss.mat', '-ascii');
X = multigauss;
f = size(X,2);
k = 5;
t0 = ones(k, 1);
mu0 = ones(k, f);
sigma0 = zeros(f, f, k);
for i = 1:k
   sigma0(:, :, i) = eye(f, f);
end

nIter = 100;
[t, mu, sigma] = EM(X, k, t0, mu0, sigma0, nIter)